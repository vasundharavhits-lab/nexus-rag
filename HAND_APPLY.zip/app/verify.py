# app/verify.py
import re
import numpy as np

MODEL_NAME = "cross-encoder/nli-deberta-v3-small"
ENTAIL = 1          # label order: contradiction, entailment, neutral
SUPPORT_MIN = 0.5   # entailment probability needed to call a claim supported

# Verbs that let a list sentence be split: "The system uses A, B and C".
LEAD_VERBS = {"uses", "use", "includes", "include", "stores", "handles", "runs",
              "adds", "provides", "supports", "contains", "combines", "relies",
              "needs", "requires"}
_SPLIT = re.compile(r"\s*;\s*|,\s+and\s+|,\s+|\s+and\s+")

# Evidence windows. The NLI model loses a claim that sits inside a long passage full of
# other sentences (measured: 0.01 on the whole chunk, 0.99 on the sentence alone), so each
# source is also checked as single sentences and neighbouring pairs; the best score wins.
WINDOW_TOPK = 6     # windows kept per source (most word overlap with the claim)
_SENT_END = re.compile(r"(?<=[.!?])\s+")
_STOP = {"the", "a", "an", "of", "to", "in", "and", "or", "is", "are", "was", "were", "be",
         "for", "on", "with", "by", "as", "at", "that", "this", "it", "its", "from", "which"}

_model = None

def get_model():
    global _model
    if _model is None:
        from sentence_transformers import CrossEncoder
        _model = CrossEncoder(MODEL_NAME)
    return _model

def _verb_index(words):
    for i, w in enumerate(words):
        if w.lower().strip(".,;:") in LEAD_VERBS:
            return i
    return None

def split_compound(text, max_parts=6):
    """Split one sentence into smaller claims. Returns [text] when unsure."""
    body = text.strip().rstrip(".!?").strip()
    segs = [s.strip() for s in _SPLIT.split(body) if s and s.strip()]
    if len(segs) < 2 or len(segs) > max_parts:
        return [body]
    first = segs[0].split()
    vi = _verb_index(first)
    later_have_verb = any(_verb_index(s.split()) is not None for s in segs[1:])
    # List mode: "The system uses A, B and C" -> repeat the opening words.
    if vi is not None and not later_have_verb and all(len(s.split()) <= 6 for s in segs[1:]):
        lead = " ".join(first[:vi + 1])
        return [segs[0]] + [f"{lead} {s}" for s in segs[1:]]
    # Independent clauses: every part is long enough to stand alone.
    if len(first) >= 4 and all(len(s.split()) >= 4 for s in segs[1:]):
        return segs
    return [body]

def split_claims(answer):
    """Split an answer into claims, with citation markers removed, plus the cited numbers."""
    parts = re.split(r"(?<=[.!?])\s+(?!\[)", answer.strip())
    sents = []
    for p in parts:
        cited = sorted({int(x) for g in re.findall(r"\[(\d+(?:\s*,\s*\d+)*)\]", p)
                        for x in g.split(",")})
        text = re.sub(r"\s*\[\d+(?:\s*,\s*\d+)*\]", "", p).strip()
        if len(text.split()) >= 3:
            sents.append({"text": text, "cited": cited})
    # Paragraph-level citations: small models often write "A. B. C. [2]". A sentence with no
    # marker of its own takes the citation of the next cited sentence, so it is checked
    # against that source instead of being treated as uncited.
    carry = []
    for s in reversed(sents):
        if s["cited"]:
            carry = s["cited"]
        else:
            s["cited"] = list(carry)
    out = []
    for s in sents:
        end = s["text"][-1] if s["text"][-1] in ".!?" else ""
        for sub in split_compound(s["text"]):
            if len(sub.split()) >= 3:
                out.append({"text": sub + end, "cited": s["cited"]})
    return out

def _entailment(pairs):
    logits = get_model().predict(pairs)
    e = np.exp(logits - logits.max(axis=1, keepdims=True))
    return (e / e.sum(axis=1, keepdims=True))[:, ENTAIL]

def _tokens(text):
    return set(re.findall(r"[a-z0-9]+", text.lower())) - _STOP

def candidate_windows(text, claim, topk=WINDOW_TOPK):
    """The whole passage, plus the `topk` single sentences / neighbouring sentence pairs
    that share the most words with the claim (single sentences win ties)."""
    flat = " ".join(text.split())
    sents = [s for s in _SENT_END.split(flat) if s]
    wins = sents + [sents[i] + " " + sents[i + 1] for i in range(len(sents) - 1)]
    want = _tokens(claim) or {""}
    ranked = sorted(set(wins), key=lambda w: (-len(want & _tokens(w)) / len(want), len(w)))
    return [flat] + [w for w in ranked[:topk] if w != flat]

def best_scores(claim, sources, only=None):
    """Entailment of `claim` for each source in `only` (default: all) = best score over that
    source's windows. The whole passage is scored first; the sentence windows are scored
    only for sources where it did not already reach SUPPORT_MIN (saves most of the cost).
    Returns ({n: score}, {n: winning window text})."""
    ns = [n for n in (list(sources) if only is None else only) if n in sources]
    best, where = {}, {}
    if not ns:
        return best, where
    wins = {n: candidate_windows(sources[n], claim) for n in ns}
    for n, s in zip(ns, _entailment([(wins[n][0], claim) for n in ns])):
        best[n], where[n] = float(s), wins[n][0]
    pairs, owners = [], []
    for n in ns:
        if best[n] < SUPPORT_MIN:
            for w in wins[n][1:]:
                pairs.append((w, claim))
                owners.append(n)
    if pairs:
        for n, (w, _), s in zip(owners, pairs, _entailment(pairs)):
            if float(s) > best[n]:
                best[n], where[n] = float(s), w
    return best, where

def verify_answer(answer, sources):
    """sources: {n: text}. Returns one result per claim."""
    results = []
    for c in split_claims(answer):
        # stage 1: the sources the answer cites; stage 2 (only if they fail): the others,
        # to tell "wrong source" from "unsupported"
        scores, where = best_scores(c["text"], sources, c["cited"])
        cited_ok = [n for n in c["cited"] if scores.get(n, 0) >= SUPPORT_MIN]
        if not cited_ok:
            s2, w2 = best_scores(c["text"], sources, [n for n in sources if n not in scores])
            scores.update(s2); where.update(w2)
        other_ok = [n for n in scores if n not in c["cited"] and scores[n] >= SUPPORT_MIN]
        if cited_ok:
            verdict = "supported"
        elif other_ok:
            verdict = "wrong_source"       # true, but cited source doesn't say it
        else:
            verdict = "unsupported"
        results.append({"claim": c["text"], "cited": c["cited"], "verdict": verdict,
                        "better_sources": other_ok if verdict == "wrong_source" else [],
                        "scores": {n: round(s, 2) for n, s in scores.items()},
                        "support": {n: where[n][:200] for n in (cited_ok or other_ok)}})
    return results