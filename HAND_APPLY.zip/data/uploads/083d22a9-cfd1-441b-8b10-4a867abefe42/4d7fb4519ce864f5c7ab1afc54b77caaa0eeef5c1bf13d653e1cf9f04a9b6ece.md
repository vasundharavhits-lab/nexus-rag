# Architecture
Status: Approved
Date: 2026-02-15

## Overview
The system is a monolithic service. Retrieval combines keyword and vector search.

## Storage
All data is stored in PostgreSQL. Redis is used for caching.

## Security
Access is checked on every request.
